const express = require('express');
const router = express.Router();
const DashboardService = require('./dashboard.service');

/**
 * Validate date string (YYYY-MM-DD)
 */
function isValidDate(dateStr) {
  if (!dateStr) return true;
  const date = new Date(dateStr);
  return !isNaN(date.getTime());
}

/**
 * GET /api/dashboard
 * Get dashboard metrics
 * Query params: asOfDate (optional, YYYY-MM-DD format)
 */
router.get('/', async (req, res) => {
  try {
    const { asOfDate } = req.query;
    
    // DEV MODE: Set tenantId for development
    let tenantId = req.user?.tenantId;
    if (!tenantId && (req.headers.authorization === 'Bearer dev-token' || req.headers['x-dev-mode'] === 'true')) {
      tenantId = '69d41e8bef18c77b2b68baac';
      console.log('🚀 Dashboard: DEV MODE tenantId set to 69d41e8bef18c77b2b68baac');
    }

    // Validate tenantId
    if (!tenantId) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    // Validate date
    if (asOfDate && !isValidDate(asOfDate)) {
      return res.status(400).json({ 
        success: false, 
        error: 'Invalid asOfDate format. Use YYYY-MM-DD' 
      });
    }

    // Get dashboard metrics
    const metrics = await DashboardService.getDashboardMetrics(
      tenantId,
      asOfDate ? new Date(asOfDate) : null
    );

    res.json({
      success: true,
      data: metrics,
      message: 'Dashboard metrics retrieved successfully'
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;